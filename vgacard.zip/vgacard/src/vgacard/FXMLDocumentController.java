package vgacard;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;


public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private TextField tfId;
    @FXML
    private TextField tfMerek;
    @FXML
    private ComboBox<?> tfJenis;
    @FXML
    private TextField tfHarga;
    @FXML
    private TextField tfJumlah;
    @FXML
    private DatePicker tfTanggal;
    @FXML
    private TableView<vgacard> tvTampil;
    @FXML
    private TableColumn<vgacard, Integer> colId;
    @FXML
    private TableColumn<vgacard, String> colMerek;
    @FXML
    private TableColumn<vgacard, String> colJenis;
    @FXML
    private TableColumn<vgacard, String> colHarga;
    @FXML
    private TableColumn<vgacard, String> colJumlah;
    @FXML
    private TableColumn<vgacard, String> colTanggal;
    @FXML
    private Button btnInsert;
    @FXML
    private Button btnUpdate;
    @FXML
    private Button btnDelete;

   @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource() == btnInsert){
            insertRecord();
        }else if (event.getSource() == btnUpdate){
            updateRecord();
        }else if(event.getSource() == btnDelete){
            deleteButton();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         showBooks();
        ArrayList <String> list = new ArrayList<String>();
        list.add("Gaming");
        list.add("Normal");
        ObservableList items = FXCollections.observableArrayList(list);
        tfJenis.setItems(items);
    }    
    
    public Connection getConnection(){
        Connection conn;
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vgacard", "root","");
            return conn;
        }catch(Exception ex){
            System.out.println("Error: " + ex.getMessage());
            return null;
        }
    }
    
    public ObservableList<vgacard> getBooksList(){
        ObservableList<vgacard> bookList = FXCollections.observableArrayList();
        Connection conn = getConnection();
        String query = "SELECT * FROM table_vgacard";
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            rs = st.executeQuery(query);
            vgacard vga;
            while(rs.next()){
                vga = new vgacard(rs.getInt("id"), rs.getString("merek"), rs.getString("jenis"), rs.getString("harga"),rs.getString("jumlah"),rs.getString("tanggal"));
                bookList.add(vga);
            }
                
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return bookList;
    }
    
    public void showBooks(){
        ObservableList<vgacard> list = getBooksList();
        
        colId.setCellValueFactory(new PropertyValueFactory<vgacard, Integer>("id"));
        colMerek.setCellValueFactory(new PropertyValueFactory<vgacard, String>("merek"));
        colJenis.setCellValueFactory(new PropertyValueFactory<vgacard, String>("jenis"));
        colHarga.setCellValueFactory(new PropertyValueFactory<vgacard, String>("harga"));
        colJumlah.setCellValueFactory(new PropertyValueFactory<vgacard, String>("jumlah"));
        colTanggal.setCellValueFactory(new PropertyValueFactory<vgacard, String>("tanggal"));
        
        tvTampil.setItems(list);
    }
    
    private void insertRecord(){
        String query = "INSERT INTO vgacard VALUES (" + tfId.getText() + ",'" + tfMerek.getText() + "','" + tfJenis.getValue().toString() + "'," + tfHarga.getText() + "','" 
                + tfJumlah.getText() + ")" + tfTanggal.getValue().toString() + ",";
        executeQuery(query);
        showBooks();
    }
    
    private void updateRecord(){
        String query = "UPDATE  vgacard SET merek  = '" + tfMerek.getText() + "', jenis = '" + tfJenis.getValue().toString() + "', harga  = '" + tfHarga.getText() + "',jumlah  = '" + tfJumlah.getText() + "' ,"
                + "tanggal = " + tfTanggal.getValue().toString() + " WHERE id = " + tfId.getText() + "";
        executeQuery(query);
        showBooks();
    }
    
    private void deleteButton(){
        String query = "DELETE FROM vgacard WHERE id =" + tfId.getText() + "";
        executeQuery(query);
        showBooks();
    }
    
    private void executeQuery(String query) {
        Connection conn = getConnection();
        Statement st;
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}

